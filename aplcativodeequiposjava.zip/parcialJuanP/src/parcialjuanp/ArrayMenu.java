/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcialjuanp;

/**
 *
 * @author Portatil
 */
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class ArrayMenu {

    private static Equipos[] equiposArray = new Equipos[100];
    private static int contadorEquipos = 0;

    public static void mostrarMenu() {
        int opcion;

        do {
            String opcionStr = JOptionPane.showInputDialog(null,
                    "Menú:\n"
                    + "1. Ingresar\n"
                    + "2. Mostrar\n"
                    + "3. Eliminar\n"
                    + "4. Ordenar campeonatos por ciudad\n"
                    + "5. Ordenar campeonatos por método Shell\n"
                    + "6. Mostrar ordenadamente equipos\n"
                    + "7. Salir\n"
                    + "Ingrese su opción:", "Menú", JOptionPane.QUESTION_MESSAGE);

            try {
                opcion = Integer.parseInt(opcionStr);

                switch (opcion) {
                    case 1:
                        ingresarEquipo();
                        break;
                    case 2:
                        mostrarEquipos();
                        break;
                    case 3:
                        eliminarEquipo();
                        break;
                    case 4:
                        mostrarDatosOrdenados();
                        break;
                    case 5:
                        ordenarCampeonatosPorShell();
                        break;
                    case 6:
                        mostrarEquiposPorNombre();
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, "Saliendo del programa...");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción no válida. Inténtelo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número del 1 al 7.", "Error", JOptionPane.ERROR_MESSAGE);
                opcion = 0; // Set opcion to 0 to force the loop to continue
            }
        } while (opcion != 7);
    }

   private static void ingresarEquipo() {
    if (contadorEquipos < equiposArray.length) {
        int codigo;
        try {
            codigo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código del equipo:"));

            // Verificar si el código ya existe
            for (int i = 0; i < contadorEquipos; i++) {
                if (equiposArray[i] != null && equiposArray[i].getCodigo() == codigo) {
                    JOptionPane.showMessageDialog(null, "El código ya existe. No se puede agregar el equipo.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Salir del método si el código ya existe
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El código debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Salir del método si la conversión falla
        }

        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del equipo:");
        String ciudad;

        do {
            ciudad = JOptionPane.showInputDialog("Ingrese la ciudad del equipo:");
            // Verificar si la ciudad contiene solo letras
            if (!ciudad.matches("[a-zA-Z]+")) {
                JOptionPane.showMessageDialog(null, "La ciudad debe contener solo letras.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (!ciudad.matches("[a-zA-Z]+"));

        int campganados;
        do {
            try {
                campganados = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de campeonatos ganados:"));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "La cantidad de campeonatos ganados debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
                campganados = -1; // Reiniciar campganados a un valor no válido para repetir el bucle
            }
        } while (campganados == -1); // Repetir el bucle si campganados es -1 (valor no válido)

        int cantidadPartidos;
        do {
            try {
                cantidadPartidos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de partidos para este equipo:"));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "La cantidad de partidos debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
                cantidadPartidos = -1; // Reiniciar cantidadPartidos a un valor no válido para repetir el bucle
            }
        } while (cantidadPartidos == -1); // Repetir el bucle si cantidadPartidos es -1 (valor no válido)

        ResultPartidos[] partidos = new ResultPartidos[cantidadPartidos];
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        for (int i = 0; i < cantidadPartidos; i++) {
            Date fecha = null;
            do {
                try {
                    String fechaStr = JOptionPane.showInputDialog("Ingrese la fecha del partido (dd/MM/yyyy):");
                    fecha = dateFormat.parse(fechaStr);
                } catch (ParseException e) {
                    JOptionPane.showMessageDialog(null, "La fecha debe tener el formato dd/MM/yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
                    fecha = null; // Reiniciar fecha a null para repetir el bucle
                }
            } while (fecha == null); // Repetir el bucle si fecha es null (formato incorrecto)

            String equipoContrario = JOptionPane.showInputDialog("Ingrese el nombre del equipo contrario:");
        
            String resultado;
            do {
                try {
                    resultado = JOptionPane.showInputDialog("Ingrese el resultado del partido:");
                    // Verificar si el resultado contiene solo números
                    if (!resultado.matches("\\d+")) {
                        JOptionPane.showMessageDialog(null, "El resultado debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
                        resultado = null; // Reiniciar resultado a null para repetir el bucle
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "El resultado debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
                    resultado = null; // Reiniciar resultado a null para repetir el bucle
                }
            } while (resultado == null); // Repetir el bucle si resultado es null (valor no válido)

            partidos[i] = new ResultPartidos(dateFormat.format(fecha), equipoContrario, resultado); // Modifica "Equipo contrario" según sea necesario
        }

        equiposArray[contadorEquipos] = new Equipos(codigo, nombre, ciudad, campganados, partidos);
        contadorEquipos++;
        JOptionPane.showMessageDialog(null, "Equipo ingresado correctamente.");
    } else {
        JOptionPane.showMessageDialog(null, "No se pueden ingresar más equipos. El límite ha sido alcanzado.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    private static void mostrarEquipos() {
        if (contadorEquipos == 0) {
            JOptionPane.showMessageDialog(null, "No hay equipos para mostrar.");
        } else {
            int codigoMostrar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código del equipo que desea mostrar:"));

            boolean encontrado = false;
            for (int i = 0; i < contadorEquipos; i++) {
                if (equiposArray[i] != null && equiposArray[i].getCodigo() == codigoMostrar) {
                    encontrado = true;
                    Equipos equipo = equiposArray[i];

                    // Crear una cadena con etiquetas descriptivas antes de cada dato
                    StringBuilder datosEquipos = new StringBuilder();
                    datosEquipos.append("Código: ").append(equipo.getCodigo()).append("\n");
                    datosEquipos.append("Nombre: ").append(equipo.getNombre()).append("\n");
                    datosEquipos.append("Ciudad: ").append(equipo.getCiudad()).append("\n");
                    datosEquipos.append("Campeonatos ganados: ").append(equipo.getCampganados()).append("\n\n");

                    // Mostrar resultados de partidos
                    StringBuilder resultadosPartidos = new StringBuilder();
                    resultadosPartidos.append("Resultados de partidos:\n");
                    resultadosPartidos.append("Fecha\t\tEquipo contrario\t\tResultado\n");
                    for (ResultPartidos partido : equipo.getResultadosPartidos()) {
                        resultadosPartidos.append(partido.getFecha()).append("\t");
                        resultadosPartidos.append(partido.getEquipoContrario()).append("\t");
                        resultadosPartidos.append(partido.getResultado()).append("\n");
                    }

                    // Mostrar los datos con etiquetas descriptivas en una ventana de diálogo
                    JOptionPane.showMessageDialog(null, datosEquipos.toString() + resultadosPartidos.toString(), "Información del Equipo", JOptionPane.PLAIN_MESSAGE);
                    break;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(null, "No se encontró un equipo con el código ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private static void eliminarEquipo() {
        if (contadorEquipos == 0) {
            JOptionPane.showMessageDialog(null, "No hay equipos para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int codigoEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código del equipo que desea eliminar:"));

            boolean encontrado = false;
            for (int i = 0; i < contadorEquipos; i++) {
                if (equiposArray[i] != null && equiposArray[i].getCodigo() == codigoEliminar) {
                    encontrado = true;
                    for (int j = i; j < contadorEquipos - 1; j++) {
                        equiposArray[j] = equiposArray[j + 1];
                    }
                    contadorEquipos--;
                    JOptionPane.showMessageDialog(null, "Equipo eliminado correctamente.");
                    break;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(null, "No se encontró un equipo con el código ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
private static void ordenarCampeonatosPorShell() {
    int n = contadorEquipos;
    int intervalo = 1;

    // Calcula el valor de intervalo (h) que será utilizado en el algoritmo de Shell
    while (intervalo < n / 3) {
        intervalo = intervalo * 3 + 1;
    }

    // Aplica el algoritmo de Shell para ordenar los equipos por cantidad de campeonatos ganados
    while (intervalo > 0) {
        for (int i = intervalo; i < n; i++) {
            Equipos tempEquipo = equiposArray[i];
            int j = i;
            // Realiza la comparación y el intercambio
            while (j >= intervalo && equiposArray[j - intervalo].getCampganados() > tempEquipo.getCampganados()) {
                equiposArray[j] = equiposArray[j - intervalo];
                j -= intervalo;
            }
            equiposArray[j] = tempEquipo;
        }
        intervalo = (intervalo - 1) / 3;
    }
    // Después de ordenar, muestra los datos ordenados
     DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Código");
    model.addColumn("Nombre");
    model.addColumn("Ciudad");
    model.addColumn("Campeonatos ganados");

    // Añadir filas con los datos de los equipos ordenados
    for (int i = 0; i < contadorEquipos; i++) {
        Equipos equipo = equiposArray[i];
        model.addRow(new Object[]{equipo.getCodigo(), equipo.getNombre(), equipo.getCiudad(), equipo.getCampganados()});
    }

    // Crear la tabla con el modelo
    JTable table = new JTable(model);

    // Colocar la tabla en un panel desplazable
    JScrollPane scrollPane = new JScrollPane(table);

    // Crear el cuadro de diálogo con la tabla y un botón para volver al menú
    JOptionPane.showMessageDialog(null, scrollPane, "Equipos ordenados por campeonatos", JOptionPane.PLAIN_MESSAGE);

}




    
private static void mostrarDatosOrdenados() {
    // Ordenar los equipos por ciudad
    for (int i = 0; i < contadorEquipos - 1; i++) {
        int indiceMenor = i;
        for (int j = i + 1; j < contadorEquipos; j++) {
            // Utilizamos compareToIgnoreCase para ignorar las diferencias de mayúsculas y minúsculas
            if (equiposArray[j].getCiudad().compareToIgnoreCase(equiposArray[indiceMenor].getCiudad()) < 0) {
                indiceMenor = j;
            }
        }
        // Intercambiar los equipos en las posiciones i e indiceMenor
        Equipos aux = equiposArray[i];
        equiposArray[i] = equiposArray[indiceMenor];
        equiposArray[indiceMenor] = aux;
    }

    // Crear el modelo de tabla y añadir columnas
    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Código");
    model.addColumn("Nombre");
    model.addColumn("Ciudad");
    model.addColumn("Campeonatos ganados");

    // Añadir filas con los datos de los equipos ordenados
    for (int i = 0; i < contadorEquipos; i++) {
        Equipos equipo = equiposArray[i];
        model.addRow(new Object[]{equipo.getCodigo(), equipo.getNombre(), equipo.getCiudad(), equipo.getCampganados()});
    }

    // Crear la tabla con el modelo
    JTable table = new JTable(model);

    // Colocar la tabla en un panel desplazable
    JScrollPane scrollPane = new JScrollPane(table);

    // Crear el cuadro de diálogo con la tabla y un botón para volver al menú
    JOptionPane.showMessageDialog(null, scrollPane, "Equipos ordenados por ciudad", JOptionPane.PLAIN_MESSAGE);
}
private static void mostrarEquiposPorNombre() {
    String nombreEquipo = JOptionPane.showInputDialog("Ingrese el nombre del equipo que desea mostrar:");

    boolean encontrado = false;
    for (int i = 0; i < contadorEquipos; i++) {
        if (equiposArray[i] != null && equiposArray[i].getNombre().equalsIgnoreCase(nombreEquipo)) {
            encontrado = true;
            Equipos equipo = equiposArray[i];

            // Crear el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Fecha");
            model.addColumn("Equipo Contrario");
            model.addColumn("Resultado");

            // Obtener los resultados de los partidos del equipo
            ResultPartidos[] partidos = equipo.getResultadosPartidos();

            // Ordenar los resultados de los partidos por fecha
            Arrays.sort(partidos, new Comparator<ResultPartidos>() {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

                @Override
                public int compare(ResultPartidos partido1, ResultPartidos partido2) {
                    try {
                        Date fecha1 = dateFormat.parse(partido1.getFecha());
                        Date fecha2 = dateFormat.parse(partido2.getFecha());
                        return fecha1.compareTo(fecha2);
                    } catch (ParseException e) {
                        e.printStackTrace();
                        return 0;
                    }
                }
            });

            // Crear una lista de nombres de equipos contrarios
            List<String> nombresEquiposContrarios = new ArrayList<>();
            for (ResultPartidos partido : partidos) {
                nombresEquiposContrarios.add(partido.getEquipoContrario());
            }

            // Ordenar alfabéticamente los nombres de equipos contrarios
            Collections.sort(nombresEquiposContrarios);

            // Añadir filas con los datos ordenados de los partidos
            for (String nombreEquipoContrario : nombresEquiposContrarios) {
                for (ResultPartidos partido : partidos) {
                    if (partido.getEquipoContrario().equals(nombreEquipoContrario)) {
                        model.addRow(new Object[]{partido.getFecha(), nombreEquipoContrario, partido.getResultado()});
                    }
                }
            }

            // Crear la tabla con el modelo y colocarla en un panel desplazable
            JTable table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);

            // Mostrar la tabla en un cuadro de diálogo
            JOptionPane.showMessageDialog(null, scrollPane, "Resultados de partidos del equipo", JOptionPane.PLAIN_MESSAGE);

            break;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(null, "No se encontró un equipo con el nombre ingresado.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private static void mostrarResultadosPartidos(Equipos equipo) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Fecha");
        model.addColumn("Equipo Contrario");
        model.addColumn("Resultado");

        for (ResultPartidos partido : equipo.getResultadosPartidos()) {
            model.addRow(new Object[]{partido.getFecha(), partido.getEquipoContrario(), partido.getResultado()});
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        JOptionPane.showMessageDialog(null, scrollPane, "Resultados de partidos del equipo", JOptionPane.PLAIN_MESSAGE);
    }
}

