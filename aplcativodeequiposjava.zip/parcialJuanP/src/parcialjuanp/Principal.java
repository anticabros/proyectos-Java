/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialjuanp;

/**
 *
 * @author Portatil
 */
public class Principal {
    public static void main(String[] args) {
        ArrayMenu menuManager = new ArrayMenu();
        menuManager.mostrarMenu();

    }
}