/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialjuanp;

/**
 *
 * @author Portatil
 */
public class ResultPartidos {
      private String fecha;
    private String equipoContrario;
    private String resultado;

    public ResultPartidos(String fecha, String equipoContrario, String resultado) {
        this.fecha = fecha;
        this.equipoContrario = equipoContrario;
        this.resultado = resultado;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getEquipoContrario() {
        return equipoContrario;
    }

    public void setEquipoContrario(String equipoContrario) {
        this.equipoContrario = equipoContrario;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}
