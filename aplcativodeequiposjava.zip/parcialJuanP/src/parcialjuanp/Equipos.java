/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialjuanp;

/**
 *
 * @author Portatil
 */
public class Equipos {
    private int codigo;
    private String nombre;
    private String ciudad;
    private int campganados;
    private ResultPartidos[] resultpartidos;

    public Equipos(int codigo, String nombre, String ciudad, int campganados, ResultPartidos[] resultpartidos) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.campganados = campganados;
        this.resultpartidos = resultpartidos;
    }
    public ResultPartidos[] getResultadosPartidos() {
    return resultpartidos;
}

    // Getters y setters
    public void setCodigo(int codigo) {    
        this.codigo = codigo;
    }

    // Método para obtener una representación de cadena de los datos del equipo
    @Override
public String toString() {
    StringBuilder resultado = new StringBuilder();
    resultado.append("Código: ").append(codigo).append("\n");
    resultado.append("Nombre: ").append(nombre).append("\n");
    resultado.append("Ciudad: ").append(ciudad).append("\n");
    resultado.append("Campeonatos ganados: ").append(campganados).append("\n\n");
    resultado.append("Resultados de partidos:\n");
    resultado.append("Fecha\t\tEquipo contrario\t\tResultado\n");
    for (ResultPartidos partido : getResultadosPartidos()) {
        resultado.append(partido.getFecha()).append("\t");
        resultado.append(partido.getEquipoContrario()).append("\t");
        resultado.append(partido.getResultado()).append("\n");
    }
    return resultado.toString();
}

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getCampganados() {
        return campganados;
    }

    public void setCampganados(int campganados) {
        this.campganados = campganados;
    }

    public ResultPartidos[] getResultpartidos() {
        return resultpartidos;
    }

    public void setResultpartidos(ResultPartidos[] resultpartidos) {
        this.resultpartidos = resultpartidos;
    }

    Iterable<ResultPartidos> getResultados() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
