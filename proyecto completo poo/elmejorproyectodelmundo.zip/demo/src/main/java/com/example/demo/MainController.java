package com.example.demo;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.ResultSet;

public class MainController {
    @FXML
    private TextField idUsuarioTextField, nombreTextField, estadoUsuarioTextField, telefonoTextField, direccionTextField, emailTextField, cedulaTextField, passwordTextField;

    @FXML
    private void guardarUsuario() {
        String idUsuario = idUsuarioTextField.getText();
        String nombre = nombreTextField.getText();
        String estado = estadoUsuarioTextField.getText();
        String telefono = telefonoTextField.getText();
        String direccion = direccionTextField.getText();
        String email = emailTextField.getText();
        String cedula = cedulaTextField.getText();
        String password = passwordTextField.getText();

        if(
                idUsuario.isEmpty()
                || nombre.isEmpty()
                || estado.isEmpty()
                || telefono.isEmpty()
                || direccion.isEmpty()
                || email.isEmpty()
                || cedula.isEmpty()
                || password.isEmpty()
        )
            return;

        System.out.println(idUsuario);
        System.out.println(nombre);
        System.out.println(estado);
        System.out.println(telefono);
        System.out.println(direccion);
        System.out.println(email);
        System.out.println(cedula);
        System.out.println(password);

        // Llamar al método para insertar el usuario en la base de datos
        String respuesta = DatabaseConnector.insertUsuario(idUsuario, nombre, estado, telefono, direccion, email, cedula, password);

        // Puedes agregar lógica adicional aquí, como mostrar un mensaje de éxito o actualizar la interfaz de usuario.
        Label responseLabel = new Label(respuesta);
        // Crear una nueva ventana emergente para mostrar la respuesta
        Stage responsePopupStage = new Stage();
        responsePopupStage.initModality(Modality.APPLICATION_MODAL);
        responsePopupStage.initStyle(StageStyle.UTILITY);
        responsePopupStage.setTitle("Respuesta de la inserción de usuario");
        // Crear el contenido de la ventana emergente con la respuesta
        Scene responsePopupScene = new Scene(responseLabel, 800, 600);

        // Establecer el contenido en la ventana emergente
        responsePopupStage.setScene(responsePopupScene);

        // Mostrar la ventana emergente con la respuesta
        responsePopupStage.showAndWait();
    }

    @FXML
    private void editarUsuario() {
        String idUsuario = idUsuarioTextField.getText();
        String nombre = nombreTextField.getText();
        String estado = estadoUsuarioTextField.getText();
        String telefono = telefonoTextField.getText();
        String direccion = direccionTextField.getText();
        String email = emailTextField.getText();
        String cedula = cedulaTextField.getText();
        String password = passwordTextField.getText();

        if(
                idUsuario.isEmpty()
                        || nombre.isEmpty()
                        || estado.isEmpty()
                        || telefono.isEmpty()
                        || direccion.isEmpty()
                        || email.isEmpty()
                        || cedula.isEmpty()
                        || password.isEmpty()
        )
            return;

        System.out.println(idUsuario);
        System.out.println(nombre);
        System.out.println(estado);
        System.out.println(telefono);
        System.out.println(direccion);
        System.out.println(email);
        System.out.println(cedula);
        System.out.println(password);

        // Llamar al método para insertar el usuario en la base de datos
        String respuesta = DatabaseConnector.editUsuario(idUsuario, nombre, estado, telefono, direccion, email, cedula, password);

        // Puedes agregar lógica adicional aquí, como mostrar un mensaje de éxito o actualizar la interfaz de usuario.
        Label responseLabel = new Label(respuesta);
        // Crear una nueva ventana emergente para mostrar la respuesta
        Stage responsePopupStage = new Stage();
        responsePopupStage.initModality(Modality.APPLICATION_MODAL);
        responsePopupStage.initStyle(StageStyle.UTILITY);
        responsePopupStage.setTitle("Respuesta de la inserción de usuario");
        // Crear el contenido de la ventana emergente con la respuesta
        Scene responsePopupScene = new Scene(responseLabel, 800, 600);

        // Establecer el contenido en la ventana emergente
        responsePopupStage.setScene(responsePopupScene);

        // Mostrar la ventana emergente con la respuesta
        responsePopupStage.showAndWait();
    }

    @FXML
    private void limpiarUsuario() {
        idUsuarioTextField.clear();
        nombreTextField.clear();
        estadoUsuarioTextField.clear();
        telefonoTextField.clear();
        direccionTextField.clear();
        emailTextField.clear();
        cedulaTextField.clear();
        passwordTextField.clear();
    }

    @FXML
    private void buscarUsuario() {
        // Llamar al método para insertar el usuario en la base de datos
        String idUsuario = idUsuarioTextField.getText();

        String[] usuario = DatabaseConnector.buscarUsuario(idUsuario);
        if (usuario != null){
            idUsuarioTextField.setText(idUsuario);
            nombreTextField.setText(usuario[0]);
            estadoUsuarioTextField.setText(usuario[1]);
            telefonoTextField.setText(usuario[2]);
            direccionTextField.setText(usuario[3]);
            emailTextField.setText(usuario[4]);
            cedulaTextField.setText(usuario[5]);
            passwordTextField.setText(usuario[6]);
        }
    }

    @FXML
    private void eliminarUsuario() {
        // Llamar al método para insertar el usuario en la base de datos
        String idUsuario = idUsuarioTextField.getText();

        if(!idUsuario.isEmpty())
        DatabaseConnector.eliminarUsuario(Integer.parseInt(idUsuario));
    }

}
